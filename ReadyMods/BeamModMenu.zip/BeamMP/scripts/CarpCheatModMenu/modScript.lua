setExtensionUnloadMode("modmenumain", "manual")
load("modmenumain")
extensions.core_input_categories.sslModMenu = { order = 1069, icon = "settings", title = "BeamMP Mod-Menu (SpiderSpeedLauncher)", desc = "Keybinds for the BeamMP/CaRP Mod-Menu" }