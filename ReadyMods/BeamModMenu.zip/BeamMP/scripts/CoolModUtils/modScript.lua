load("CoolModUtils")
setExtensionUnloadMode("CoolModUtils", "manual")